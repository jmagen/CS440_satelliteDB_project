<?php
  // Define database connection constants
  define('DB_HOST', 'classmysql.engr.oregonstate.edu');
  define('DB_USER', 'cs440_hutchico');
  define('DB_PASSWORD', '4827');
  define('DB_NAME', 'cs440_hutchico');
  define('CON_STRING', 'mysql:host=classmysql.engr.oregonstate.edu;dname=cs440_hutchico');
?>

